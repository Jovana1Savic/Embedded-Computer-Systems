/*
 * @file dma.c
 *
 * @brief Defines functions used to initialize DMA channels 0 and 1.
 *
 */

#include "dma.h"

/* Initialize channel 0.*/
void vInitDMA0( uint8_t* sourceAddress, uint8_t* destAddress, uint16_t numOfBytes )
{
    DMACTL0 |= DMA0TSEL_0;      //!< Select DMAREQ trigger.
    DMA0CTL |= DMADT_1;         //!< Select block transfer.
    DMA0CTL |= DMADSTINCR_3;    //!< Increment destination address.
    DMA0CTL |= DMASRCINCR_3;    //!< Source address increment.
    DMA0CTL |= DMADSTBYTE;      //!< Destination size is bytes.
    DMA0CTL |= DMASRCBYTE;      //!< Source size is bytes.
    DMA0CTL |= DMAIE;           //!< Enable interrupt.

    DMA0SA = (__SFR_FARPTR)sourceAddress;     //!< Set source address.
    DMA0DA = (__SFR_FARPTR)destAddress;       //!< Set destination address.
    DMA0SZ = numOfBytes;        //!< Set block size.

    DMA0CTL |= DMAEN;           //!< Enable DMA.
}

/* Initialize channel 1. */
void vInitDMA1( uint8_t* sourceAddress, uint8_t* destAddress, uint16_t numOfBytes )
{
    DMACTL0 |= DMA1TSEL_0;      //!< Select DMAREQ trigger.
    DMA1CTL |= DMADT_1;         //!< Select block transfer.
    DMA1CTL |= DMADSTINCR_3;    //!< Increment destination address.
    DMA1CTL |= DMASRCINCR_3;    //!< Source address increment.
    DMA1CTL |= DMADSTBYTE;      //!< Destination size is bytes.
    DMA1CTL |= DMASRCBYTE;      //!< Source size is bytes.
    DMA1CTL |= DMAIE;           //!< Enable interrupt.

    DMA1SA = (__SFR_FARPTR)sourceAddress;     //!< Set source address.
    DMA1DA = (__SFR_FARPTR)destAddress;       //!< Set destination address.
    DMA1SZ = numOfBytes;        //!< Set block size.

    DMA1CTL |= DMAEN;           //!< Enable DMA.
}
