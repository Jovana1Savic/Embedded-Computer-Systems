/*
 * @file dma.h
 *
 * @brief DMA interface.
 *
 * @detail Functions used to initialize DMA.
 *
 * @date May 2018
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#include "stdint.h"
#include <msp430.h>

/*
 * @brief Initialize channel 0.
 *
 * @detail Initialize channel 0 so that numOfBytes from array which sourceAddress is given
 * are transfered byte by byte into array given with destAddress. DMA interrupt is enabled.
 */
extern void vInitDMA0( uint8_t* sourceAddress, uint8_t* destAddress, uint16_t numOfBytes );

/*
 * @brief Initialize channel 1.
 *
 * @detail Initialize channel 0 so that numOfBytes from array which sourceAddress is given
 * are transfered byte by byte into array given with destAddress. DMA interrupt is enabled.
 */
extern void vInitDMA1( uint8_t* sourceAddress, uint8_t* destAddress, uint16_t numOfBytes );
