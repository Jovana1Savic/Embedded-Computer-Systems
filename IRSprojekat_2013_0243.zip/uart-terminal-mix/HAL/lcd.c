/*
 * @file lcd.c
 *
 * @brief LCD display functions implementations.
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#include "lcd.h"

/*-----------------------------------------------------------------------------
 *
 *                  Interface functions definitions.
 *
 *-----------------------------------------------------------------------------
 */

/**
 * Initialize LCD display.
 */
void vInitLCD( void )
{

    /* Set data and control ports to output */
    LCD_DIR |= LCD_D7 | LCD_D6 | LCD_D5 | LCD_D4 | LCD_RS | LCD_EN;
    LCD_OUT &= ~0xF0;

    vWaitMilliseconds( 5 )             //!< Wait 5 ms.

    vSendCommand( USE_4BITS );          //!< Initialize for 4bit operation.
    vWaitMilliseconds( 4 )

    vSendCommand( 0x32 );          //!< Do it again.
    vWaitMilliseconds( 4 )

    vSendCommand( LINES_2_5x8_MAT );    //!< Use 2 lines and 5x8 matrix.
    vWaitMilliseconds( 0.2 )

    vSendCommand( LINES_2_5x8_MAT );
    vWaitMilliseconds( 0.2 )

    vSendCommand( LCD_ON_CURSOR_ON );   //!< LCD on, cursor blinking.
    vWaitMilliseconds( 0.2 )

    vSendCommand( CLEAR_DISPLAY );   //!< Clear display.
    vWaitMilliseconds( 2 )

    vSendCommand( CURSOR_INC );         //!< Cursor increments.
    vWaitMilliseconds( 0.2 )

    vSendCommand( CUR_TO_BEG_FIRST );  //!< Set cursor to the beginning.
    vWaitMilliseconds( 1 )
}

/**
 * Send data to LCD display.
 */
void vSendChar( uint8_t ucData )
{
    /* Send upper nibble */
    LCD_OUT |= LCD_RS;              //!< Set RS to 1 to signal that this is data.
    vSendNibble( ucData, 1 );       //!< Send upper nibble.

    /* Send lower nibble */
    LCD_OUT |= LCD_RS;              //!< Set RS to 1 to signal that this is data.
    vSendNibble( ucData, 0 );       //!< Send lower nibble.
}

/**
 * Send string to LCD display.
 */
void vSendString( const uint8_t* ucString )
{
    vClearDisplay();
    while ( (*ucString) != '\0' )
        vSendChar( *ucString++ );
}

/**
 * Clear display and return home.
 */
void vClearDisplay( void )
{
    vSendCommand( CLEAR_DISPLAY );
    vWaitMilliseconds( 2 )

    vSendCommand( RETURN_HOME );
    vWaitMilliseconds( 2 )
}

/*
 * Set cursor position.
 */
void vSetCursorPosition( uint8_t ucLine, uint8_t ucPosition )
{
    uint8_t ucCommand = ucCursorPosition( ucLine, ucPosition );
    vSendCommand( ucCommand );
    vWaitMilliseconds( 1 )
}


/*
 * Send string with given position.
 */

void vDisplayString( const uint8_t* ucString, uint8_t ucLine, uint8_t ucPosition )
{
    vSetCursorPosition( ucLine, ucPosition );
    while ( (*ucString) != '\0' )
        vSendChar( *ucString++ );
}

/*-----------------------------------------------------------------------------
 *
 *                  Helper functions definitions.
 *
 *-----------------------------------------------------------------------------
 */

/**
 *  Get code for command that sets cursor position and line.
 */
uint8_t ucCursorPosition( uint8_t ucLine, uint8_t ucPosition )
{

    /* When given improper parameters go to first line, position 0. */
    if ( ( ucLine != 1 ) && ( ucLine != 2 ) )
        return CUR_TO_BEG_FIRST;
    if ( ucPosition >= 16 )
        return CUR_TO_BEG_FIRST;

    if ( ucLine == 1 )
        return CUR_TO_BEG_FIRST | ucPosition;

    return CUR_TO_BEG_SECOND | ucPosition;
}

/*
 *  Helper method - Send upper or lower nibble of ucData to data bits. Depending on RS bit
 *  they will be interpreted as command or data.
 */
void vSendNibble( uint8_t ucData, uint8_t ucUpper )
{

    LCD_OUT &= ~LCD_DATA;                   //!< Clear upper 4 bits (data bits).

    if ( ucUpper )                          //!< If upper, get upper 4 bits.
        ucData &= 0xF0;
    else                                    //!< Else, get lower 4 bits.
        ucData = ( ucData << 4 ) & 0xF0;

    LCD_OUT |= ucData & LCD_DATA;           //!< Set data bits.

    enable();                               //!< Set enable falling edge.

}

/*
 *  Enable EN signal.
 */
void enable()
{
    LCD_OUT &= ~LCD_EN;                     //<! Make sure it's zero.
    vWaitMilliseconds( 2 )

    LCD_OUT |= LCD_EN;                      //<! Set to 1.
    vWaitMilliseconds( 2 )

    LCD_OUT &= ~LCD_EN;                     //<! Set to 0 to create falling edge.
    vWaitMilliseconds( 2 )
}

/**
 * Send command to LCD display.
 */
void vSendCommand( uint8_t ucCommand )
{
    /* Send upper nibble */
    LCD_OUT &= ~LCD_RS;             //!< Set RS to 0 to signal that this is command.
    vSendNibble( ucCommand, 1 );    //!< Send upper nibble.

    /* Send lower nibble */
    LCD_OUT &= ~LCD_RS;             //!< Set RS to 0 to signal that this is command.
    vSendNibble( ucCommand, 0 );    //!< Send lower nibble.

}
