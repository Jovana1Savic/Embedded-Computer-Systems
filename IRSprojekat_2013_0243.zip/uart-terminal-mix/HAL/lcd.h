/**
 * @file lcd.h
 * @brief Hardware abstraction layer for LCD display.
 *
 * @date May 2018
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#ifndef _LCD_H_
#define _LCD_H_

/**
 * Standard includes.
 */
#include "stdint.h"
#include "msp430.h"


/* Ports */
#define LCD_DIR     ( P8DIR )
#define LCD_OUT     ( P8OUT )

/* Data signals */
#define LCD_D7      ( BIT7 )
#define LCD_D6      ( BIT6 )
#define LCD_D5      ( BIT5 )
#define LCD_D4      ( BIT4 )
#define LCD_DATA    ( 0xF0 )

/* Control signals */
#define LCD_EN      ( BIT3 )
#define LCD_RS      ( BIT2 )

/* Common commands. */
#define LCD_ON_CURSOR_ON    ( 0x0F )    //!< LCD on, cursor on.
#define DISP_ON_CURSOR_B    ( 0x0E )    //!< Display on, cursor blinking.
#define CLEAR_DISPLAY       ( 0x01 )    //!< Clear display screen.
#define RETURN_HOME         ( 0x02 )    //!< Return home.
#define CURSOR_DEC          ( 0x04 )    //!< Decrement cursor.
#define CURSOR_INC          ( 0x06 )    //!< Increment cursor.
#define SHIFT_DISP_RIGHT    ( 0x05 )    //!< Shift display right.
#define SHIFT_DISP_LEFT     ( 0x07 )    //!< Shift display left.
#define CUR_TO_BEG_FIRST    ( 0x80 )    //!< Force cursor to beginning of first line.
#define CUR_TO_BEG_SECOND   ( 0xC0 )    //!< Force cursor to beginning of second line.
#define LINES_2_5x7_MAT     ( 0x38 )    //!< Use 2 lines and 5x7 matrix.
#define ACT_SECOND_LINE     ( 0x3C )    //!< Activate second line.
#define DISP_OFF_CURSOR_OFF ( 0x08 )    //!< Display OFF, cursor OFF.
#define DISP_ON_CURSOR_OFF  ( 0x0C )    //!< Display ON, cursor OFF.
#define USE_4BITS           ( 0x33 )    //!< Use 4 bit operations.
#define LINES_2_5x8_MAT     ( 0x28 )    //!< Use 2 lines, 5x8 matrix.

/*-----------------------------------------------------------------------------
 *
 *                  Interface functions declarations.
 *
 *-----------------------------------------------------------------------------
 */

/**
 * Wait milliseconds. Note that this isn't very precise, but it is precise
 * enough for LCD display.
 */
#define vWaitMilliseconds( ms )   __delay_cycles( ms*1000 );

/**
 * @brief Initialize LCD display hardware.
 *
 * @detail Set port directions and initialize display as 5x7 matrix with blinking
 * cursor at the beginning of the first line.
 */
extern void vInitLCD( void );

/**
 * @brief Send character to LCD display.
 *
 * @detail Send char to LCD display as two nibbles.
 */
extern void vSendChar( uint8_t ucData );

/**
 * @brief Display string from the beginning of the first line.
 *
 * @detail Clears display and displays given string.
 */
extern void vSendString( const uint8_t* ucString );

/**
 * @brief Clears display and returns home.
 *
 * @detail Clears display and puts cursor at the beginning of
 * the first line.
 */
extern void vClearDisplay( void );

/**
 * @brief Set cursor to position.
 *
 * @detail Sets cursor to given position.
 */
extern void vSetCursorPosition( uint8_t ucLine, uint8_t ucPosition );

/**
 * @brief Display string starting from given position and line.
 *
 * @detail Display string starting from given position. You need to make sure that
 * it fits.
 */
extern void vDisplayString( const uint8_t* ucString, uint8_t ucLine, uint8_t ucPosition );


/*-----------------------------------------------------------------------------
 *
 *                  Helper functions declarations.
 *              Not intended to be used outside led.c file.
 *
 *-----------------------------------------------------------------------------
 */

/**
 * @brief Get code for command for setting cursor position.
 */
extern uint8_t ucCursorPosition( uint8_t ucLine, uint8_t ucPosition );

/**
 * @brief Helper function - set nibble to data bits. If ucUpper is 1, set upper nibble,
 * else set lower. This function does not care about RS bit, set it properly before using it.
 */
extern void vSendNibble( uint8_t ucData, uint8_t ucUpper );

/**
 * @brief Abstracts sending enable signal.
 */
extern void enable();

/**
 * @brief Send command to LCD display.
 *
 * @detail Send command to LCD display as two nibbles.
 */
extern void vSendCommand( uint8_t ucCommand );

#endif
