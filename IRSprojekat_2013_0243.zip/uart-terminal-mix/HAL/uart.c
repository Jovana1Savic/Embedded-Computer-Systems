/*
 * @file gps.c
 *
 * @brief Implements UART initialization and contains C interrupt routine.
 */
#include <uart.h>

/* Buffer used when sending data from terminal. Data is saved so that it can
 * be echoed back. This eases testing.
 */
uint8_t ucRXBuffer[255];
uint8_t ucRXBufferCount = 0;                //!< Buffer - RX counter.
uint8_t ucTXBufferCount = 0;                //!< Buffer - TX counter.

/*
 * @brief Initialize UART at port P5 at 9600 baud rate with RX interrupt enabled.
 *
 * @detail GPS is connected to this port. When testing via terminal this function
 * is not used.
 */

void vInitUART( void )
{
    /* Use UCA1 to communicate with GPS.*/
    P5SEL |= BIT6 | BIT7;               //!< Configure P5.6 and P5.7 for UART.

    UCA1CTL1 |= UCSWRST;                //!< Enter SW reset.

    UCA1CTL0 = 0;
    UCA1CTL1 = UCSSEL__ACLK | UCSWRST;
    UCA1BRW = 3;
    UCA1MCTL = UCBRS_3;                 //!< Configure 9600 BPS.

    UCA1CTL1 &= ~UCSWRST;               //!< Leave SW reset.

    UCA1IE |= UCRXIE;                   //!< Enable RX interrupt.

}

#ifndef 1

/*
 * @brief Initialize UART at port P3 at 9600 baud rate with RX and TX interrupts enabled.
 *
 * @detail This port is used when NMEA messages are sent via terminal, that is
 * for testing purposes. This function shouldn't be used when working with GPS.
 * The messages are also echoed back in order to ease testing.
 */
void vInitUART( void )
{
    /* Use UCA0 (terminal) for testing. */
    P3SEL |= BIT4 | BIT5;              //!< Configure P5.6 and P6.7 for UART.

    UCA1CTL1 |= UCSWRST;                //!< Enter SW reset.

    UCA0CTL0 = 0;
    UCA0CTL1 = UCSSEL__ACLK | UCSWRST;
    UCA0BRW = 3;
    UCA0MCTL = UCBRS_3;                 //!< Configure 9600 BPS.

    UCA0CTL1 &= ~UCSWRST;               //!< Leave SW reset.

    UCA0IFG = 0;                        //!< clear IFG
    UCA0IE |= UCRXIE | UCTXIE;          //!< enable rx and tx interrupts
}
#endif

/*
 * @brief C interrupt routine for UART on port P3.
 *
 * @detail Stores received data to buffer declared at the begging of this file.
 * Not used in main program, but can be used for testing if needed.
 */
#ifndef 1
void __attribute__ ((interrupt(USCI_A1_VECTOR))) UARTISR (void)
{
    switch (UCA1IV)
    {
    case 2:                 // RXIFG
        ucRXBuffer[ucRXBufferSize++] = UCA1RXBUF;  // save data
        break;
    default:
        break;
    }
}
#endif

