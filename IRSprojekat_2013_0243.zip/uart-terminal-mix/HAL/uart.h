/**
 * @file gps.h
 *
 * @brief Hardware abstraction layer for GPS module NEO-6 and
 *        controller communication via UART.
 *
 * @detail GPS module sends various messages. The ones we are interested
 *         in are GPA which contain longitude and latitude and GSA which contains
 *         dilution of precision.
 *
 * @date May 2018
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#include "stdint.h"
#include <msp430.h>

extern uint8_t ucRXBuffer[255];                //!< Message buffer.
extern uint8_t ucRXBufferSize;                 //!< Buffer size - buffer counter.
extern uint8_t ucTXBufferCount;                   //!< Buffer - TX counter.

/*
 * @brief Initialize UART.
 *
 * @detail Enable RX interrupt and set baud rate to 9600.
 * When testing is done NMEA messages are sent via terminal and UART is initialized
 * at port 3. When communicating with GPS UART is initialized at port 5. Since they
 * both use the same state machine the behavior would be undefined if both are active.
 */
extern void vInitUART( void );

