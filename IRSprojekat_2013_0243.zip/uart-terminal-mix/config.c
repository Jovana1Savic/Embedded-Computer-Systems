/**
 * @file configure_hardware.c
 * @brief Implementation of functions used to configure all necessary hardware.
 *
 * @date May 2018
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#include "config.h"

extern uint8_t* ucMyMessageGGA_tmp;
extern uint8_t* ucMyMessageGGA;
extern uint8_t* ucMyMessageGSA_tmp;
extern uint8_t* ucMyMessageGSA;

void configure_hardware( void )
{
        WDTCTL = WDTPW | WDTHOLD;           //!< Stop watch-dog timer.

        vInitLCD();                         //!< Initialize LCD.

        vInitUART();                         //!< Initialize UART

        vInitTimerA0();                     //!< Initialize timer A0.

        vInitButton();                      //!< Initialize button.

        //!< Initialize DMA channel 0 - GGA message
        vInitDMA0( &ucMyMessageGGA_tmp, &ucMyMessageGGA, 19 );

        //!< Initialize DMA channel 1 - GSA message
        vInitDMA1( &ucMyMessageGSA_tmp, &ucMyMessageGSA, 4 );

        vInitTimerB0();                  //!< Initialize timer A1.

        __enable_interrupt();               //!< Enable interrupts.

}


void vInitTimerA0( void )
{
    TA0CTL |= TASSEL__ACLK | MC__UP;        //!< ACLK source, UP mode
    TA0CCR0 = 1;                           //!< Set the count up value: approx. 0.5ms
}

void vInitTimerB0( void )
{
    TB0CTL |= TASSEL__ACLK | MC__UP;        //!< ACLK source, UP mode, f_ACLK = 32768 Hz
    TB0CCR0 = 32768*2-4;
    TB0CCTL0 |= CCIE;                       //!< Enable interrupt.
}

void vInitButton( void )
{
    P2DIR &= ~BIT7;                         //!< P2.7 as in.
    P2IES |= BIT7;                          //!< Interrupt on falling edge
    P2IFG &= ~BIT7;                         //!< Clear interrupt flag.
    P2IE |= BIT7;                           //!< Enable interrupt.
}
