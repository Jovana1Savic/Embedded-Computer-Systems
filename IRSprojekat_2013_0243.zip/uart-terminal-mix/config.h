/**
 * @file configure_hardware.h
 * @brief Functions used to configure hardware at the beginning.
 *
 * @date May 2018
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#ifndef __CONFIGURE_HARDWARE_H
#define __CONFIGURE_HARDWARE_H

#include "lcd.h"
#include "dma.h"
#include "HAL/uart.h"

 /**
 * @brief Hardware Configuration
 *
 * @detail  Stop watchdog timer, initialize LCD, UART (UCA1), DMA, timer A0,
 * button S4 (Port 2) and enable interrupts.
 *
 */
extern void configure_hardware( void );

/**
* @brief Timer A0 initialization
*
* @detail  Set up interrupt to 2ms but don't enable interrupt.
*
*/
extern void vInitTimerA0( void );

/**
* @brief Timer A1 initialization
*
* @detail  Sends interrupt with given period. Period is in milliseconds.
*
*/
extern void vInitTimerB0( void );

/**
* @brief Button S4 initialization
*
* @detail  Set as input port, enable interrupt on falling edge.
*
*/
extern void vInitButton( void );

 #endif /* __CONFIGURE_HARDWARE_H */
