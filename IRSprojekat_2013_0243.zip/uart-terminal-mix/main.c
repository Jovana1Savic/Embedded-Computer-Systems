/**
 * @file main.c
 * @brief  GPS module NEO-6 is sending data to MCU using UART.
 *         MCU is processing received data and writes coordinates and
 *         dilution of precision on LCD.
 * @detail GPS module is sending various messages. We are interested in GGA
 *         message which contains coordinates and GSA message which contains dilution
 *         of precision. NMEA messages contain checksum at their end, and this is
 *         used to check if the received message is valid. Because of this, received
 *         data is put in a buffer, and only if the message received was valid, it will
 *         be transfered to array that contains data.
 *
 *         Two screens are used - one to display the coordinates and one to display
 *         the dilution of precision. A button (S4) is used to toggle active screen.
 *
 *         Timers are used to display data on LCD display. One timer is used to send
 *         characters and one with much bigger period is used to refresh the screen.
 *
 * @date May 2018
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#include "config.h"
#include "dma.h"
#include <msp430.h>
#include <uart.h>

/*-----------------------------------------------------------------------------
 *
 *                Test variables and functions definitions.
 *
 *-----------------------------------------------------------------------------
 */

/* Variables and functions used for testing purposes. (GPS won't send actual coordinates
 * when inside so a test message is sent).
 */
uint8_t testMsg[] = "497,W,49.2,0.00,220518,,E*42 $GPGGA,084102.113,4254.931,N,08102.497,W,0,00,,,M,,M,,*50 $GPGLL,,V*31 $GPGSA,A,3,07,16,11,01,01,09.8,0.2*39 $$ $GPGSA,A,3,,,,,,16,18,,22,24,,,3.6,2.1,2.2*3C";
uint8_t testCounter = 0;
/*
 * @brief Test function - used to read test message.
 *
 * @detail Returns char by char from test message. When done disables RX interrupt.
 *
 * */
uint8_t returnTest()
{
    uint8_t ret = testMsg[testCounter];
    testCounter++;
    if (testCounter == 255)
        UCA1IE &= ~UCRXIE;
    return ret;
}

/*-----------------------------------------------------------------------------
 *
 *                  Global variables and functions.
 *
 *-----------------------------------------------------------------------------
 */

 /* Last successfully received GGA message :
  * [0,7] Latitude Value
  * 8 Latitude (N or S)
  * [9 - 17] Longitude value
  * 18 Longitude (W or E)
  */
 uint8_t ucMyMessageGGA[19] = "???????????????????";
 /* Buffer for message that's being currently received, which might not be correct. */
 uint8_t ucMyMessageGGA_tmp[19] = "???????????????????";

 /* Last successfully received GSA message :
  * [0,2] Dilution of precision
  */
uint8_t ucMyMessageGSA[4] = "????";
 /* Buffer for message that's being currently received, which might not be correct. */
uint8_t ucMyMessageGSA_tmp[4]= "????";

  /* Message state - represents message state machine.
   * See uart_isr.asm for states.
   * See http://www.gpsinformation.org/dale/nmea.htm for NMEA protocol and GSA and GGA
   * messages.
   */
uint8_t ucMyMessageState = 0;
  /* Temporary checksum - the one received from GPS */
uint8_t ucTmpCheckSum = 0;
  /* Current checksum - the one calculated from the message. */
uint8_t ucCurCheckSum = 0;
/* Counter used to store received data. */
uint8_t ucTmpCounter = 0;

/* Current active screen - when BIT0 is reset to 0 it displays coordinates.
 * When BIT0 is set it displays dilution of precision.
 */
uint8_t ucScreen = 0;

/* Counter used for timer A0 - timer which sends chars to LCD display. */
uint8_t ucTimerA0counter = 0;

/* Counter used for timer B0 - timer which activates timer A0's interrupts. */
uint8_t ucTimerB0counter = 0;
/*
 * @brief Converts char that represents hexadecimal number to integer.
 *
 * @detail Both lower and upper case letters are valid.
 */
 uint8_t ucHex2int(char ch)
 {
     if (ch >= '0' && ch <= '9')
         return ch - '0';
     if (ch >= 'A' && ch <= 'F')
         return ch - 'A' + 10;
     if (ch >= 'a' && ch <= 'f')
         return ch - 'a' + 10;
     return 0;
 }

 /*-----------------------------------------------------------------------------
  *
  *                             Main program.
  *
  *-----------------------------------------------------------------------------
  */

int main(void)
{
    configure_hardware();
    vSendString("Hello!");
    while(1);

}
